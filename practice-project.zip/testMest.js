<section>
    <h2>Some other content...</h2>
    <div className="my-modal">
        <h2>A Modal titile!</h2>
    </div>
    <form>
        <label>username</label>
        <input type="text"></input>
    </form>
</section>
